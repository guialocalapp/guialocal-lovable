import React, { useState, useEffect, useCallback } from 'react';
    import { Helmet } from 'react-helmet-async';
    import { useAuth } from '@/hooks/useAuth';
    import { useUsers } from '@/hooks/useUsers';
    import { usePlans } from '@/hooks/usePlans';
    import { useToast } from '@/components/ui/use-toast';
    import useViaCep from '@/hooks/useViaCep';
    import { Button } from '@/components/ui/button';
    import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
    import { Label } from '@/components/ui/label';
    import { Input } from '@/components/ui/input';
    import { Loader2, Copy } from 'lucide-react';
    
    const ClientProfile = () => {
        const { user, fetchProfile, updateUserPassword } = useAuth();
        const { updateUser, getUserById } = useUsers();
        const { getPlanById } = usePlans();
        const { toast } = useToast();
    
        const [formData, setFormData] = useState({
            full_name: '',
            email: '',
            phone: '',
            doc: '',
            street: '',
            number: '',
            complement: '',
            neighborhood: '',
            zipCode: '',
            city: '',
            state: '',
            password: '',
            confirmPassword: '',
        });
        const [currentPlan, setCurrentPlan] = useState(null);
        const [affiliate, setAffiliate] = useState(null);
        const [loading, setLoading] = useState(false);
        const [affiliateLink, setAffiliateLink] = useState('');
    
        const { loading: isCepLoading } = useViaCep(formData.zipCode, {
            onSuccess: (data) => {
                 setFormData(prev => ({
                    ...prev,
                    street: data.logradouro || prev.street,
                    neighborhood: data.bairro || prev.neighborhood,
                    city: data.localidade || prev.city,
                    state: data.uf || prev.state,
                }));
            },
            onError: () => {
                 toast({ variant: "destructive", title: "CEP não encontrado", description: "Verifique o CEP digitado." });
            }
        });
    
        useEffect(() => {
            if (user && user.profile) {
                setFormData(prev => ({
                    ...prev,
                    full_name: user.profile.full_name || '',
                    email: user.email || '',
                    phone: user.profile.phone || '',
                    doc: user.profile.doc || '',
                    street: user.profile.street || '',
                    number: user.profile.number || '',
                    complement: user.profile.complement || '',
                    neighborhood: user.profile.neighborhood || '',
                    zipCode: user.profile.zipCode || '',
                    city: user.profile.city || '',
                    state: user.profile.state || '',
                }));
                if (user.profile.plan_id) {
                    const plan = getPlanById(user.profile.plan_id);
                    setCurrentPlan(plan);
                }
                if (user.profile.affiliate_id) {
                    const affiliateUser = getUserById(user.profile.affiliate_id);
                    setAffiliate(affiliateUser);
                }
                setAffiliateLink(`${window.location.origin}/cadastro?afiliado=${user.id}`);
            }
        }, [user, getPlanById, getUserById]);
    
        const handleInputChange = (e) => {
            const { id, value } = e.target;
            setFormData(prev => ({ ...prev, [id]: value }));
        };
    
        const handleSubmit = async (e) => {
            e.preventDefault();
            setLoading(true);
            const { password, confirmPassword, ...profileData } = formData;
    
            if (password && password !== confirmPassword) {
                toast({ variant: "destructive", title: "Erro!", description: "As senhas não coincidem." });
                setLoading(false);
                return;
            }
    
            try {
                const { error: profileError } = await updateUser(user.id, profileData);
                if (profileError) {
                    throw new Error("Não foi possível atualizar os dados do perfil.");
                }
    
                if (password) {
                    const { error: passwordError } = await updateUserPassword(password);
                    if (passwordError) {
                       throw new Error("Não foi possível atualizar a senha.");
                    }
                }
                
                await fetchProfile(user.id);
                toast({ title: "Sucesso!", description: "Perfil atualizado." });
                setFormData(prev => ({...prev, password: '', confirmPassword: ''}));
    
            } catch (error) {
                toast({ variant: "destructive", title: "Erro!", description: error.message });
            } finally {
                setLoading(false);
            }
        };

        const copyToClipboard = () => {
            navigator.clipboard.writeText(affiliateLink);
            toast({ title: "Link copiado!", description: "Seu link de afiliado foi copiado para a área de transferência." });
        };
    
        if (!user || !user.profile) {
            return <div className="text-center py-20">Carregando...</div>;
        }
    
        return (
            <>
                <Helmet>
                    <title>Meu Perfil - Cliente - Guia Local</title>
                </Helmet>
                
                <Card>
                    <form onSubmit={handleSubmit}>
                        <CardHeader>
                            <CardTitle>Meu Perfil</CardTitle>
                            <CardDescription>Mantenha seus dados cadastrais sempre atualizados.</CardDescription>
                        </CardHeader>
                        <CardContent className="space-y-8">
                            <div className="space-y-4">
                                <h3 className="text-lg font-medium text-white">Programa de Afiliados</h3>
                                <CardDescription>Compartilhe seu link e ganhe benefícios a cada novo cliente cadastrado!</CardDescription>
                                <div className="flex items-center space-x-2">
                                    <Input value={affiliateLink} readOnly />
                                    <Button type="button" size="icon" onClick={copyToClipboard}>
                                        <Copy className="h-4 w-4" />
                                    </Button>
                                </div>
                            </div>

                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                {currentPlan && (
                                    <div className="rounded-lg border border-dashed border-purple-800 bg-purple-950/20 p-4">
                                       <p className="text-sm text-gray-300">Seu plano atual:</p>
                                       <p className="text-lg font-bold text-white">{currentPlan.name}</p>
                                   </div>
                                )}
                                {affiliate && (
                                    <div className="rounded-lg border border-dashed border-green-800 bg-green-950/20 p-4">
                                       <p className="text-sm text-gray-300">Você foi indicado por:</p>
                                       <p className="text-lg font-bold text-white">{affiliate.full_name}</p>
                                   </div>
                                )}
                            </div>
                            
                            <div className="space-y-4">
                                <h3 className="text-lg font-medium text-white">Informações Pessoais</h3>
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                    <div>
                                        <Label htmlFor="full_name">Nome Completo</Label>
                                        <Input id="full_name" value={formData.full_name} onChange={handleInputChange} />
                                    </div>
                                    <div>
                                        <Label htmlFor="email">E-mail</Label>
                                        <Input id="email" type="email" value={formData.email} onChange={handleInputChange} disabled />
                                    </div>
                                </div>
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                    <div>
                                        <Label htmlFor="phone">Telefone</Label>
                                        <Input id="phone" value={formData.phone} onChange={handleInputChange} />
                                    </div>
                                    <div>
                                        <Label htmlFor="doc">CPF/CNPJ</Label>
                                        <Input id="doc" value={formData.doc} onChange={handleInputChange} />
                                    </div>
                                </div>
                            </div>
    
                            <div className="space-y-4">
                               <h3 className="text-lg font-medium text-white">Endereço</h3>
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                    <div className="relative">
                                        <Label htmlFor="zipCode">CEP</Label>
                                        <Input id="zipCode" value={formData.zipCode} onChange={handleInputChange} />
                                        {isCepLoading && <Loader2 className="absolute right-3 top-9 h-4 w-4 animate-spin" />}
                                    </div>
                                </div>
                                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                                   <div className="md:col-span-2">
                                        <Label htmlFor="street">Logradouro</Label>
                                        <Input id="street" value={formData.street} onChange={handleInputChange} />
                                    </div>
                                    <div>
                                        <Label htmlFor="number">Número</Label>
                                        <Input id="number" value={formData.number} onChange={handleInputChange} />
                                    </div>
                                </div>
                                 <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                                    <div>
                                        <Label htmlFor="complement">Complemento</Label>
                                        <Input id="complement" value={formData.complement} onChange={handleInputChange} />
                                    </div>
                                    <div className="md:col-span-2">
                                        <Label htmlFor="neighborhood">Bairro</Label>
                                        <Input id="neighborhood" value={formData.neighborhood} onChange={handleInputChange} />
                                    </div>
                                </div>
                                 <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                    <div>
                                        <Label htmlFor="city">Cidade</Label>
                                        <Input id="city" value={formData.city} onChange={handleInputChange} />
                                    </div>
                                    <div>
                                        <Label htmlFor="state">Estado</Label>
                                        <Input id="state" value={formData.state} onChange={handleInputChange} />
                                    </div>
                                </div>
                            </div>
    
                            <div className="space-y-4">
                                <h3 className="text-lg font-medium text-white">Alterar Senha</h3>
                                <CardDescription>Deixe em branco para não alterar.</CardDescription>
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                   <div>
                                        <Label htmlFor="password">Nova Senha</Label>
                                        <Input id="password" type="password" value={formData.password} onChange={handleInputChange} />
                                   </div>
                                   <div>
                                        <Label htmlFor="confirmPassword">Confirmar Nova Senha</Label>
                                        <Input id="confirmPassword" type="password" value={formData.confirmPassword} onChange={handleInputChange} />
                                   </div>
                                </div>
                            </div>
                        </CardContent>
                        <CardFooter className="flex justify-end">
                            <Button type="submit" disabled={loading}>
                                {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                                Salvar Alterações
                            </Button>
                        </CardFooter>
                    </form>
                </Card>
            </>
        );
    };
    
    export default ClientProfile;