import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet-async';
import { useAuth } from '@/hooks/useAuth';
import { useUsers } from '@/hooks/useUsers';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Loader2, Copy } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useToast } from '@/components/ui/use-toast';

const ClientAffiliates = () => {
    const { user } = useAuth();
    const { getAffiliatesByUserId, loading } = useUsers();
    const [affiliates, setAffiliates] = useState([]);
    const [affiliateLink, setAffiliateLink] = useState('');
    const { toast } = useToast();

    useEffect(() => {
        if (user) {
            const fetchAffiliates = async () => {
                const data = await getAffiliatesByUserId(user.id);
                setAffiliates(data);
            };
            fetchAffiliates();
            setAffiliateLink(`${window.location.origin}/cadastro?afiliado=${user.id}`);
        }
    }, [user, getAffiliatesByUserId]);

    const copyToClipboard = () => {
        navigator.clipboard.writeText(affiliateLink);
        toast({ title: "Link copiado!", description: "Seu link de afiliado foi copiado para a área de transferência." });
    };

    const formatDate = (dateString) => {
        if (!dateString) return 'N/A';
        const date = new Date(dateString);
        return new Intl.DateTimeFormat('pt-BR').format(date);
    };

    const formatCurrency = (value) => {
        if (typeof value !== 'number') return 'N/A';
        return value.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
    };

    return (
        <>
            <Helmet>
                <title>Meus Afiliados - Cliente - Guia Local</title>
            </Helmet>
            <div className="space-y-6">
                <h1 className="text-3xl font-bold tracking-tight">Programa de Afiliados</h1>
                
                <Card>
                    <CardHeader>
                        <CardTitle>Seu Link de Indicação</CardTitle>
                        <CardDescription>Compartilhe este link para convidar novos clientes e ganhar benefícios.</CardDescription>
                    </CardHeader>
                    <CardContent>
                        <div className="flex items-center space-x-2">
                            <Input value={affiliateLink} readOnly />
                            <Button type="button" size="icon" onClick={copyToClipboard}>
                                <Copy className="h-4 w-4" />
                            </Button>
                        </div>
                    </CardContent>
                </Card>

                <Card>
                    <CardHeader>
                        <CardTitle>Clientes Indicados por Você</CardTitle>
                        <CardDescription>Acompanhe aqui todos os clientes que se cadastraram através do seu link e suas comissões.</CardDescription>
                    </CardHeader>
                    <CardContent>
                        {loading ? (
                            <div className="flex justify-center items-center h-40">
                                <Loader2 className="h-8 w-8 animate-spin text-primary" />
                            </div>
                        ) : (
                            <Table>
                                <TableHeader>
                                    <TableRow>
                                        <TableHead>Cliente</TableHead>
                                        <TableHead>Plano Atual</TableHead>
                                        <TableHead>Data Contratação</TableHead>
                                        <TableHead>Valor a Receber</TableHead>
                                        <TableHead>Previsão de Pagamento</TableHead>
                                    </TableRow>
                                </TableHeader>
                                <TableBody>
                                    {affiliates.length > 0 ? (
                                        affiliates.map((affiliate) => (
                                            <TableRow key={affiliate.id}>
                                                <TableCell className="font-medium">
                                                    <div className="font-medium text-white">{affiliate.full_name}</div>
                                                    <div className="text-sm text-muted-foreground">{affiliate.email}</div>
                                                </TableCell>
                                                <TableCell>{affiliate.plan?.name || 'Plano Gratuito'}</TableCell>
                                                <TableCell>{formatDate(affiliate.planHiredDate)}</TableCell>
                                                <TableCell>{formatCurrency(affiliate.commissionValue)}</TableCell>
                                                <TableCell>{formatDate(affiliate.paymentDueDate)}</TableCell>
                                            </TableRow>
                                        ))
                                    ) : (
                                        <TableRow>
                                            <TableCell colSpan="5" className="h-24 text-center">
                                                Você ainda não indicou nenhum cliente.
                                            </TableCell>
                                        </TableRow>
                                    )}
                                </TableBody>
                            </Table>
                        )}
                    </CardContent>
                </Card>
            </div>
        </>
    );
};

export default ClientAffiliates;