import React from 'react';
import { Helmet } from 'react-helmet-async';
import { useAuth } from '@/hooks/useAuth';
import { useAds } from '@/hooks/useAds';
import { usePlans } from '@/hooks/usePlans';
import { useAdStatus } from '@/contexts/AdStatusContext';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Newspaper, Star, PlusCircle, Gem } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';

const ClientDashboard = () => {
    const { user } = useAuth();
    const { ads } = useAds();
    const { getPlanById } = usePlans();
    const { statuses } = useAdStatus();

    const clientAds = React.useMemo(() => {
        if (!user) return [];
        return ads.filter(ad => ad.user_id === user.id);
    }, [ads, user]);

    const clientPlan = React.useMemo(() => {
        if (!user?.profile?.plan_id) return null;
        return getPlanById(user.profile.plan_id);
    }, [user, getPlanById]);

    const activeStatusId = React.useMemo(() => statuses.find(s => s.name.toLowerCase() === 'ativo')?.id, [statuses]);
    const activeAdsCount = React.useMemo(() => clientAds.filter(ad => ad.listing_status_id === activeStatusId).length, [clientAds, activeStatusId]);
    const adLimit = clientPlan?.adLimit ?? 1;
    const planName = clientPlan?.name ?? 'Plano Básico';

    if (!user || !user.profile) {
        return <div className="text-center py-20">Carregando...</div>;
    }

    const formatCurrency = (value) => {
        if (typeof value !== 'number') return 'R$ 0,00';
        return value.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
    };

    return (
        <>
            <Helmet>
                <title>Dashboard - Cliente - Guia Local</title>
            </Helmet>
            <div className="space-y-6">
                <div className="flex flex-col md:flex-row md:items-center md:justify-between">
                    <h1 className="text-2xl md:text-3xl font-bold tracking-tight">Olá, {user.profile.full_name?.split(' ')[0]}!</h1>
                    <p className="text-muted-foreground mt-1 md:mt-0">Bem-vindo(a) ao seu painel.</p>
                </div>
                
                <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                     <Card>
                        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                            <CardTitle className="text-sm font-medium">Seu Plano</CardTitle>
                            <Gem className="h-4 w-4 text-muted-foreground" />
                        </CardHeader>
                        <CardContent>
                            <div className="text-2xl font-bold">{planName}</div>
                            <p className="text-xs text-muted-foreground">{clientPlan ? formatCurrency(clientPlan.monthlyPrice) : 'Gratuito'}</p>
                        </CardContent>
                    </Card>
                    <Card>
                        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                            <CardTitle className="text-sm font-medium">Anúncios Ativos</CardTitle>
                            <Newspaper className="h-4 w-4 text-muted-foreground" />
                        </CardHeader>
                        <CardContent>
                            <div className="text-2xl font-bold">{activeAdsCount} / {adLimit === -1 ? '∞' : adLimit}</div>
                            <p className="text-xs text-muted-foreground">Limite do plano atual</p>
                        </CardContent>
                    </Card>
                </div>

                <Card className="bg-primary/5 border-primary/20">
                    <CardHeader>
                        <CardTitle className="flex items-center gap-3">
                            <PlusCircle className="w-8 h-8 text-primary" />
                            <span className="text-xl">Crie ou gerencie seus anúncios</span>
                        </CardTitle>
                    </CardHeader>
                    <CardContent>
                        <p className="text-muted-foreground mb-4">Destaque seu negócio no Guia Local e alcance mais clientes.</p>
                        <Button asChild>
                            <Link to="/client/listings">Meus Anúncios</Link>
                        </Button>
                    </CardContent>
                </Card>
            </div>
        </>
    );
};

export default ClientDashboard;