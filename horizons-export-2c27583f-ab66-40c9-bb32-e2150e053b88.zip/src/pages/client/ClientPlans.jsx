import React, { useState } from 'react';
import { Helmet } from 'react-helmet-async';
import { usePlans } from '@/hooks/usePlans';
import { useAuth } from '@/hooks/useAuth';
import { Button } from '@/components/ui/button';
import { Check, X } from 'lucide-react';
import { cn } from '@/lib/utils';
import { useNavigate } from 'react-router-dom';

const formatCurrency = (value) => {
    if (typeof value !== 'number') return 'R$ 0,00';
    return value.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
};

const ClientPlans = () => {
    const { plans, loading: plansLoading } = usePlans();
    const { user, loading: authLoading } = useAuth();
    const navigate = useNavigate();
    const [billingCycle, setBillingCycle] = useState('monthly');

    const handleSubscribe = (planId) => {
        navigate(`/checkout/${planId}`);
    };

    const loading = plansLoading || authLoading;

    if (loading) {
        return <div>Carregando...</div>;
    }
    
    const sortedPlans = [...plans].sort((a, b) => a.monthlyPrice - b.monthlyPrice);

    return (
        <>
            <Helmet>
                <title>Planos e Assinatura - Guia Local</title>
            </Helmet>
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
                <div className="text-center">
                    <h1 className="text-4xl font-extrabold text-white sm:text-5xl sm:tracking-tight lg:text-6xl">
                        Planos e Preços
                    </h1>
                    <p className="mt-5 max-w-xl mx-auto text-xl text-gray-400">
                        Escolha o plano perfeito para destacar seu negócio em nossa plataforma.
                    </p>
                    <div className="mt-8 flex justify-center">
                        <div className="relative rounded-full p-1 bg-gray-800 flex">
                            <button
                                onClick={() => setBillingCycle('monthly')}
                                className={cn(
                                    "relative w-1/2 rounded-full py-2 text-sm font-medium text-white whitespace-nowrap focus:outline-none focus:ring-2 focus:ring-primary focus:ring-offset-2 focus:ring-offset-background",
                                    billingCycle === 'monthly' ? 'bg-primary' : 'hover:bg-gray-700'
                                )}
                            >
                                Pagamento Mensal
                            </button>
                            <button
                                onClick={() => setBillingCycle('annually')}
                                className={cn(
                                    "relative w-1/2 rounded-full py-2 text-sm font-medium text-white whitespace-nowrap focus:outline-none focus:ring-2 focus:ring-primary focus:ring-offset-2 focus:ring-offset-background",
                                    billingCycle === 'annually' ? 'bg-primary' : 'hover:bg-gray-700'
                                )}
                            >
                                Pagamento Anual
                            </button>
                        </div>
                    </div>
                </div>

                <div className="mt-12 space-y-4 sm:mt-16 sm:space-y-0 sm:grid sm:grid-cols-2 sm:gap-6 lg:max-w-4xl lg:mx-auto xl:max-w-none xl:mx-0 xl:grid-cols-4">
                    {sortedPlans.map((plan) => {
                        const isCurrentPlan = plan.id === user?.profile?.plan_id;
                        const price = billingCycle === 'monthly' ? plan.monthlyPrice : plan.annualPrice;
                        const features = [
                            { text: `${plan.adLimit === -1 ? 'Ilimitados' : plan.adLimit} anúncios`, included: true },
                            { text: `${plan.imageLimit === -1 ? 'Ilimitadas' : plan.imageLimit} imagens por anúncio`, included: true },
                            { text: `Suporte prioritário`, included: plan.monthlyPrice > 20 },
                            { text: `Destaque na busca`, included: plan.monthlyPrice > 50 },
                        ];

                        return (
                            <div key={plan.id} className={cn("rounded-lg shadow-lg border-2 flex flex-col", isCurrentPlan ? 'border-primary bg-card' : 'border-border bg-card')}>
                                <div className="p-6 flex-grow">
                                    <h2 className="text-lg leading-6 font-medium text-foreground">{plan.name}</h2>
                                    <p className="mt-4 text-sm text-muted-foreground" dangerouslySetInnerHTML={{ __html: plan.description }} />
                                    <p className="mt-8">
                                        <span className="text-4xl font-extrabold text-foreground">{price === 0 ? "Gratuito" : formatCurrency(price)}</span>
                                        {price !== 0 && <span className="text-base font-medium text-muted-foreground">/{billingCycle === 'monthly' ? 'mês' : 'ano'}</span>}
                                    </p>
                                </div>
                                <div className="p-6">
                                    {isCurrentPlan ? (
                                        <Button className="w-full" disabled>
                                            Seu Plano Atual
                                        </Button>
                                    ) : (
                                        <Button onClick={() => handleSubscribe(plan.id)} className="w-full">
                                            Assinar
                                        </Button>
                                    )}
                                </div>
                                <div className="pt-6 pb-8 px-6">
                                    <h3 className="text-xs font-medium text-muted-foreground tracking-wide uppercase">O que está incluso</h3>
                                    <ul role="list" className="mt-6 space-y-4">
                                        {features.map((feature) => (
                                            <li key={feature.text} className="flex space-x-3">
                                                {feature.included ? (
                                                    <Check className="flex-shrink-0 h-5 w-5 text-green-500" aria-hidden="true" />
                                                ) : (
                                                    <X className="flex-shrink-0 h-5 w-5 text-destructive" aria-hidden="true" />
                                                )}
                                                <span className="text-sm text-muted-foreground">{feature.text}</span>
                                            </li>
                                        ))}
                                    </ul>
                                </div>
                            </div>
                        );
                    })}
                </div>
            </div>
        </>
    );
};
    
export default ClientPlans;