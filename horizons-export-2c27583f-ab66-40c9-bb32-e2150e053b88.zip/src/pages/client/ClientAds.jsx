import React from 'react';
import { Helmet } from 'react-helmet-async';
import { useNavigate, Link } from 'react-router-dom';
import { useToast } from '@/components/ui/use-toast';
import { Button } from '@/components/ui/button';
import { PlusCircle, Edit, Trash2, MoreHorizontal } from 'lucide-react';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { useAds } from '@/hooks/useAds';
import { usePlans } from '@/hooks/usePlans';
import { useCities } from '@/hooks/useCities';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { Badge } from '@/components/ui/badge';
import { useAdStatus } from '@/contexts/AdStatusContext';

const ClientAds = () => {
    const { toast } = useToast();
    const { user, loading: authLoading } = useAuth();
    const { ads, deleteAd, loading: adsLoading } = useAds();
    const { getPlanById, loading: plansLoading } = usePlans();
    const { statuses, loading: statusesLoading } = useAdStatus();
    const { getCityById, loading: citiesLoading } = useCities();
    
    const clientAds = React.useMemo(() => {
        if (!user) return [];
        return ads.filter(ad => ad.user_id === user.id);
    }, [ads, user]);

    const clientPlan = React.useMemo(() => {
        if (!user || !user.profile?.plan_id) return null;
        return getPlanById(user.profile.plan_id);
    }, [user, getPlanById]);
    
    const activeStatusId = React.useMemo(() => statuses.find(s => s.name.toLowerCase() === 'ativo')?.id, [statuses]);
    const activeAdsCount = React.useMemo(() => clientAds.filter(ad => ad.listing_status_id === activeStatusId).length, [clientAds, activeStatusId]);
    const adLimit = clientPlan?.adLimit ?? 0;
    
    const getStatusName = (id) => statuses.find(s => s.id === id)?.name || 'N/A';
    const getCityName = (id) => {
        const city = getCityById(id);
        return city ? `${city.name} / ${city.state}` : 'N/A';
    };

    const handleDelete = async (id) => {
        await deleteAd(id);
    };

    const getModerationBadgeVariant = (status) => {
        switch (status) {
            case 'Aprovado':
                return 'success';
            case 'Reprovado':
                return 'destructive';
            case 'Em moderação':
                return 'secondary';
            default:
                return 'outline';
        }
    };

    const loading = authLoading || adsLoading || plansLoading || statusesLoading || citiesLoading;

    return (
        <>
            <Helmet>
                <title>Meus Anúncios - Cliente - Guia Local</title>
            </Helmet>
            <div className="flex items-center justify-between space-y-2 mb-6">
                <h1 className="text-3xl font-bold tracking-tight">Meus Anúncios</h1>
                <Button asChild>
                    <Link to="/client/listings/new">
                        <PlusCircle className="mr-2 h-4 w-4" /> Criar Novo Anúncio
                    </Link>
                </Button>
            </div>
            
            <Card>
                <CardHeader>
                    <CardTitle>Seus Anúncios</CardTitle>
                    <CardDescription>
                        Gerencie aqui os seus anúncios cadastrados. 
                        {clientPlan && ` Plano atual: ${clientPlan.name}. Anúncios ativos: ${activeAdsCount} de ${adLimit === -1 ? 'Ilimitados' : adLimit}.`}
                    </CardDescription>
                </CardHeader>
                <CardContent>
                     <Table>
                        <TableHeader>
                            <TableRow>
                                <TableHead>Título</TableHead>
                                <TableHead>Status</TableHead>
                                <TableHead>Moderação</TableHead>
                                <TableHead>
                                    <span className="sr-only">Ações</span>
                                </TableHead>
                            </TableRow>
                        </TableHeader>
                        <TableBody>
                            {loading ? (
                                <TableRow>
                                    <TableCell colSpan={4} className="h-24 text-center">
                                        Carregando...
                                    </TableCell>
                                </TableRow>
                            ) : clientAds && clientAds.length > 0 ? (
                                clientAds.map(ad => (
                                    <TableRow key={ad.id}>
                                        <TableCell className="font-medium">{ad.title}</TableCell>
                                        <TableCell>
                                            <Badge variant="secondary">{getStatusName(ad.listing_status_id)}</Badge>
                                        </TableCell>
                                        <TableCell>
                                            <Badge variant={getModerationBadgeVariant(ad.moderation_status)}>{ad.moderation_status}</Badge>
                                        </TableCell>
                                        <TableCell className="text-right">
                                            <DropdownMenu>
                                                <DropdownMenuTrigger asChild>
                                                    <Button aria-haspopup="true" size="icon" variant="ghost">
                                                        <MoreHorizontal className="h-4 w-4" />
                                                        <span className="sr-only">Toggle menu</span>
                                                    </Button>
                                                </DropdownMenuTrigger>
                                                <DropdownMenuContent align="end">
                                                    <DropdownMenuLabel>Ações</DropdownMenuLabel>
                                                     <DropdownMenuItem asChild>
                                                        <Link to={`/client/listings/edit/${ad.id}`} className="cursor-pointer flex items-center">
                                                            <Edit className="mr-2 h-4 w-4" /> Editar
                                                        </Link>
                                                    </DropdownMenuItem>
                                                    <DropdownMenuSeparator />
                                                    <AlertDialog>
                                                        <AlertDialogTrigger asChild>
                                                            <DropdownMenuItem onSelect={(e) => e.preventDefault()} className="cursor-pointer">
                                                                <span className="text-red-500 flex items-center">
                                                                    <Trash2 className="mr-2 h-4 w-4" /> Excluir
                                                                </span>
                                                            </DropdownMenuItem>
                                                        </AlertDialogTrigger>
                                                        <AlertDialogContent>
                                                            <AlertDialogHeader>
                                                                <AlertDialogTitle>Você tem certeza?</AlertDialogTitle>
                                                                <AlertDialogDescription>
                                                                    Essa ação não pode ser desfeita. Isso excluirá permanentemente o anúncio.
                                                                </AlertDialogDescription>
                                                            </AlertDialogHeader>
                                                            <AlertDialogFooter>
                                                                <AlertDialogCancel>Cancelar</AlertDialogCancel>
                                                                <AlertDialogAction onClick={() => handleDelete(ad.id)}>Excluir</AlertDialogAction>
                                                            </AlertDialogFooter>
                                                        </AlertDialogContent>
                                                    </AlertDialog>
                                                </DropdownMenuContent>
                                            </DropdownMenu>
                                        </TableCell>
                                    </TableRow>
                                ))
                            ) : (
                                <TableRow>
                                    <TableCell colSpan={4} className="h-24 text-center">
                                        Nenhum anúncio encontrado.
                                    </TableCell>
                                </TableRow>
                            )}
                        </TableBody>
                    </Table>
                </CardContent>
            </Card>
        </>
    );
};

export default ClientAds;