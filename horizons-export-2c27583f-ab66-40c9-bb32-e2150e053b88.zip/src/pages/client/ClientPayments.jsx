import React from 'react';
import { Helmet } from 'react-helmet-async';
import { usePayments } from '@/hooks/usePayments';
import { useAuth } from '@/hooks/useAuth';
import { usePlans } from '@/hooks/usePlans';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { CreditCard, ScanLine, AlertCircle, CheckCircle, Clock, Ban } from 'lucide-react';

const formatCurrency = (value) => {
    if (typeof value !== 'number') return 'R$ 0,00';
    return value.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
};

const formatDate = (dateString) => {
    return new Date(dateString).toLocaleDateString('pt-BR', {
        day: '2-digit',
        month: '2-digit',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
    });
};

const StatusBadge = ({ status }) => {
    switch (status) {
        case 'CONFIRMED':
        case 'RECEIVED':
            return <Badge className="bg-green-600/20 text-green-400 border-green-600/30 hover:bg-green-600/30"><CheckCircle className="w-3 h-3 mr-1" /> Confirmado</Badge>;
        case 'PENDING':
            return <Badge variant="secondary" className="bg-yellow-600/20 text-yellow-400 border-yellow-600/30 hover:bg-yellow-600/30"><Clock className="w-3 h-3 mr-1" /> Pendente</Badge>;
        case 'FAILED':
            return <Badge variant="destructive" className="bg-red-600/20 text-red-400 border-red-600/30 hover:bg-red-600/30"><AlertCircle className="w-3 h-3 mr-1" /> Falhou</Badge>;
        case 'EXPIRED':
            return <Badge variant="destructive" className="bg-orange-600/20 text-orange-400 border-orange-600/30 hover:bg-orange-600/30"><Ban className="w-3 h-3 mr-1" /> Expirado</Badge>;
        default:
            return <Badge variant="outline">{status}</Badge>;
    }
};

const PaymentMethodIcon = ({ method }) => {
    switch (method) {
        case 'CREDIT_CARD':
            return <div className="flex items-center gap-2"><CreditCard className="w-4 h-4 text-gray-400" /> Cartão</div>;
        case 'PIX':
            return <div className="flex items-center gap-2"><ScanLine className="w-4 h-4 text-gray-400" /> PIX</div>;
        default:
            return method;
    }
}

const ClientPayments = () => {
    const { user } = useAuth();
    const { payments, loading } = usePayments();
    const { getPlanById } = usePlans();

    const clientPayments = React.useMemo(() => {
        if (!user) return [];
        return payments.filter(p => p.user_id === user.id);
    }, [payments, user]);

    return (
        <>
            <Helmet>
                <title>Meus Pagamentos - Cliente - Guia Local</title>
            </Helmet>
            <h1 className="text-3xl font-bold tracking-tight mb-6">Meus Pagamentos</h1>
            
            <Card>
                <CardHeader>
                    <CardTitle>Histórico de Transações</CardTitle>
                    <CardDescription>Aqui você pode visualizar todos os seus pagamentos e status de assinatura.</CardDescription>
                </CardHeader>
                <CardContent>
                     <Table>
                        <TableHeader>
                            <TableRow>
                                <TableHead>Data</TableHead>
                                <TableHead>Plano</TableHead>
                                <TableHead>Valor</TableHead>
                                <TableHead>Método</TableHead>
                                <TableHead>Status</TableHead>
                            </TableRow>
                        </TableHeader>
                        <TableBody>
                            {loading ? (
                                <TableRow>
                                    <TableCell colSpan={5} className="h-24 text-center">
                                        Carregando histórico...
                                    </TableCell>
                                </TableRow>
                            ) : clientPayments.length > 0 ? (
                                clientPayments.map(payment => (
                                    <TableRow key={payment.id}>
                                        <TableCell>{formatDate(payment.created_at)}</TableCell>
                                        <TableCell>{getPlanById(payment.plan_id)?.name || 'N/A'}</TableCell>
                                        <TableCell>{formatCurrency(payment.amount)}</TableCell>
                                        <TableCell><PaymentMethodIcon method={payment.billing_type} /></TableCell>
                                        <TableCell><StatusBadge status={payment.status} /></TableCell>
                                    </TableRow>
                                ))
                            ) : (
                                <TableRow>
                                    <TableCell colSpan={5} className="h-24 text-center">
                                        Nenhum pagamento encontrado.
                                    </TableCell>
                                </TableRow>
                            )}
                        </TableBody>
                    </Table>
                </CardContent>
            </Card>
        </>
    );
};

export default ClientPayments;