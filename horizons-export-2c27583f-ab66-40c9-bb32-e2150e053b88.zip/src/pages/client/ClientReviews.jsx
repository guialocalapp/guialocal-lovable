import React from 'react';
import { Helmet } from 'react-helmet-async';
import { Link } from 'react-router-dom';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { useReviews } from '@/contexts/ReviewContext';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import StarRating from '@/components/site/StarRating';

const ClientReviews = () => {
    const { user } = useAuth();
    const { reviews, loading } = useReviews();

    const receivedReviews = reviews.filter(r => r.listing?.user_id === user.id);
    const myReviews = reviews.filter(r => r.user_id === user.id);

    const getStatusBadgeVariant = (status) => {
        switch (status) {
            case 'Aprovado':
                return 'success';
            case 'Reprovado':
                return 'destructive';
            default:
                return 'secondary';
        }
    };

    const renderTable = (data, type) => (
        <Table>
            <TableHeader>
                <TableRow>
                    <TableHead>{type === 'received' ? 'Avaliador' : 'Anúncio'}</TableHead>
                    <TableHead>Nota</TableHead>
                    <TableHead>Comentário</TableHead>
                    <TableHead>Data</TableHead>
                </TableRow>
            </TableHeader>
            <TableBody>
                {loading ? (
                    <TableRow>
                        <TableCell colSpan={4} className="h-24 text-center">Carregando...</TableCell>
                    </TableRow>
                ) : data.length > 0 ? (
                    data.map(review => (
                        <TableRow key={review.id}>
                            <TableCell className="font-medium">
                                {type === 'received' ? review.user?.full_name : 
                                <Link to={`/anuncio/${review.listing?.slug}`} className="hover:underline">{review.listing?.title}</Link>}
                            </TableCell>
                            <TableCell><StarRating rating={review.rating} /></TableCell>
                            <TableCell className="max-w-sm truncate">{review.comment || 'N/A'}</TableCell>
                            <TableCell>{new Date(review.created_at).toLocaleDateString()}</TableCell>
                        </TableRow>
                    ))
                ) : (
                    <TableRow>
                        <TableCell colSpan={4} className="h-24 text-center">Nenhuma avaliação encontrada.</TableCell>
                    </TableRow>
                )}
            </TableBody>
        </Table>
    );

    return (
        <>
            <Helmet>
                <title>Minhas Avaliações - Cliente - Guia Local</title>
            </Helmet>
            <div className="flex items-center justify-between space-y-2 mb-6">
                <h1 className="text-3xl font-bold tracking-tight">Gerenciar Avaliações</h1>
            </div>

            <Tabs defaultValue="received" className="w-full">
                <TabsList className="grid w-full grid-cols-2">
                    <TabsTrigger value="received">Avaliações Recebidas</TabsTrigger>
                    <TabsTrigger value="my-reviews">Minhas Avaliações</TabsTrigger>
                </TabsList>
                <TabsContent value="received">
                    <Card>
                        <CardHeader>
                            <CardTitle>Avaliações Recebidas</CardTitle>
                            <CardDescription>Avaliações que seus anúncios receberam de outros usuários.</CardDescription>
                        </CardHeader>
                        <CardContent>
                            {renderTable(receivedReviews, 'received')}
                        </CardContent>
                    </Card>
                </TabsContent>
                <TabsContent value="my-reviews">
                    <Card>
                        <CardHeader>
                            <CardTitle>Minhas Avaliações</CardTitle>
                            <CardDescription>Avaliações que você fez em outros anúncios.</CardDescription>
                        </CardHeader>
                        <CardContent>
                             {renderTable(myReviews, 'my')}
                        </CardContent>
                    </Card>
                </TabsContent>
            </Tabs>
        </>
    );
};

export default ClientReviews;