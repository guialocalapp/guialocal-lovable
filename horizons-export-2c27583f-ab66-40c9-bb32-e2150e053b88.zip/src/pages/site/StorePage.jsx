import React from 'react';
import { Helmet } from 'react-helmet-async';
import ProductsList from '@/components/ProductsList';

const StorePage = () => {
  return (
    <>
      <Helmet>
        <title>Loja - Guia Local</title>
        <meta name="description" content="Confira nossos produtos exclusivos." />
      </Helmet>
      <div className="space-y-8">
        <div className="text-center">
          <h1 className="text-4xl md:text-5xl font-extrabold text-foreground tracking-tight mb-4">
            Nossa Loja
          </h1>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Descubra produtos incríveis e exclusivos, selecionados especialmente para você.
          </p>
        </div>
        <ProductsList />
      </div>
    </>
  );
};

export default StorePage;