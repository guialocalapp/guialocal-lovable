import React, { useState, useEffect, useCallback } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import { usePlans } from '@/hooks/usePlans';
import { useAuth } from '@/hooks/useAuth';
import { useMercadoPago } from '@/contexts/MercadoPagoContext';
import { usePaymentGateway } from '@/contexts/PaymentGatewayContext';
import { usePayments } from '@/hooks/usePayments';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Loader2, CreditCard, ScanLine, Lock } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import { MaskedInput } from '@/components/ui/masked-input';
import { useDebouncedViaCep } from '@/hooks/useDebouncedViaCep';
import { cn } from '@/lib/utils';

const formatCurrency = (value) => {
    if (typeof value !== 'number') return 'R$ 0,00';
    return value.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
};

const CheckoutPage = () => {
    const { planId } = useParams();
    const navigate = useNavigate();
    const { toast } = useToast();
    const { user, loading: authLoading } = useAuth();
    const { getPlanById, loading: plansLoading } = usePlans();
    const { createSubscription: createMpSubscription, loading: mpLoading, initializeMercadoPago, generateCardToken, isMercadoPagoReady } = useMercadoPago();
    const { settings: gatewaySettings, loading: gatewayLoading } = usePaymentGateway();
    const { addPayment } = usePayments();

    const [plan, setPlan] = useState(null);
    const [billingCycle, setBillingCycle] = useState('monthly');
    const [paymentMethod, setPaymentMethod] = useState('CREDIT_CARD');
    
    const [cardInfo, setCardInfo] = useState({
        holderName: '',
        number: '',
        expiry: '',
        ccv: '',
    });

    const [customerInfo, setCustomerInfo] = useState({
        fullName: '',
        email: '',
        phone: '',
        doc: '',
        zipCode: '',
        street: '',
        number: '',
        complement: '',
        neighborhood: '',
        city: '',
        state: '',
    });

    const [formErrors, setFormErrors] = useState({});
    const [isFormValid, setIsFormValid] = useState(false);

    const { address: viaCepAddress, loading: viaCepLoading } = useDebouncedViaCep(customerInfo.zipCode);

    useEffect(() => {
        if (gatewaySettings?.activeGateway === 'mercado_pago') {
            initializeMercadoPago();
        }
    }, [gatewaySettings, initializeMercadoPago]);

    useEffect(() => {
        if (viaCepAddress) {
            setCustomerInfo(prev => ({
                ...prev,
                street: viaCepAddress.logradouro || '',
                neighborhood: viaCepAddress.bairro || '',
                city: viaCepAddress.localidade || '',
                state: viaCepAddress.uf || '',
            }));
        }
    }, [viaCepAddress]);

    useEffect(() => {
        const selectedPlan = getPlanById(planId);
        if (selectedPlan) {
            setPlan(selectedPlan);
        } else if (!plansLoading) {
            navigate('/planos');
        }
    }, [planId, getPlanById, plansLoading, navigate]);

    useEffect(() => {
        if (user?.profile) {
            setCustomerInfo({
                fullName: user.profile.full_name || '',
                email: user.email || '',
                phone: user.profile.phone || '',
                doc: user.profile.doc || '',
                zipCode: user.profile.zipCode || '',
                street: user.profile.street || '',
                number: user.profile.number || '',
                complement: user.profile.complement || '',
                neighborhood: user.profile.neighborhood || '',
                city: user.profile.city || '',
                state: user.profile.state || '',
            });
        }
    }, [user]);

    const validateForm = useCallback(() => {
        const errors = {};
        const requiredCustomerFields = ['fullName', 'email', 'phone', 'doc', 'zipCode', 'street', 'number', 'neighborhood', 'city', 'state'];
        requiredCustomerFields.forEach(field => {
            if (!customerInfo[field]) {
                errors[field] = true;
            }
        });

        if (paymentMethod === 'CREDIT_CARD') {
            const requiredCardFields = ['holderName', 'number', 'expiry', 'ccv'];
            requiredCardFields.forEach(field => {
                if (!cardInfo[field]) {
                    errors[field] = true;
                }
            });
            if (cardInfo.number.replace(/\D/g, '').length < 13) errors.number = true;
            if (cardInfo.expiry.replace(/\D/g, '').length < 4) errors.expiry = true;
            if (cardInfo.ccv.replace(/\D/g, '').length < 3) errors.ccv = true;
        }

        setFormErrors(errors);
        setIsFormValid(Object.keys(errors).length === 0);
    }, [customerInfo, cardInfo, paymentMethod]);

    useEffect(() => {
        validateForm();
    }, [customerInfo, cardInfo, paymentMethod, validateForm]);

    const handleCardInputChange = (e) => {
        const { name, value } = e.target;
        setCardInfo(prev => ({ ...prev, [name]: value }));
    };

    const handleCustomerInfoChange = (e) => {
        const { name, value } = e.target;
        setCustomerInfo(prev => ({ ...prev, [name]: value }));
    };

    const getPrice = useCallback(() => {
        if (!plan) return 0;
        return billingCycle === 'monthly' ? plan.monthlyPrice : plan.annualPrice;
    }, [plan, billingCycle]);

    const handleSubmit = async (e) => {
        e.preventDefault();
        validateForm();
        if (!isFormValid) {
            toast({
                variant: 'destructive',
                title: 'Campos Incompletos',
                description: 'Por favor, preencha todos os campos obrigatórios destacados.',
            });
            return;
        }
        if (!user || !plan) return;

        const price = getPrice();

        const localPayment = await addPayment({
            user_id: user.id,
            plan_id: plan.id,
            amount: price,
            billing_type: paymentMethod,
            status: 'PENDING',
            billing_cycle: billingCycle,
            gateway: gatewaySettings.activeGateway,
        });

        if (!localPayment) {
            toast({ variant: 'destructive', title: 'Erro ao iniciar pagamento', description: 'Não foi possível registrar o pagamento localmente.' });
            return;
        }

        const [firstName, ...lastNameParts] = (customerInfo.fullName || '').split(' ');
        const lastName = lastNameParts.join(' ');

        if (gatewaySettings.activeGateway === 'mercado_pago') {
            let mpPayload = {
                plan_name: plan.name,
                local_payment_id: localPayment.id,
                transaction_amount: price,
                billing_cycle: billingCycle,
                billing_type: paymentMethod,
                payer: {
                    email: customerInfo.email,
                    first_name: firstName,
                    last_name: lastName,
                    identification: {
                        type: 'CPF',
                        number: customerInfo.doc.replace(/\D/g, ''),
                    },
                    address: {
                        zip_code: customerInfo.zipCode.replace(/\D/g, ''),
                        street_name: customerInfo.street,
                        street_number: customerInfo.number,
                        neighborhood: customerInfo.neighborhood,
                        city: customerInfo.city,
                        federal_unit: customerInfo.state,
                    }
                },
            };

            if (paymentMethod === 'CREDIT_CARD') {
                const [expiryMonth, expiryYear] = cardInfo.expiry.split('/');
                const cardToken = await generateCardToken({
                    cardholderName: cardInfo.holderName,
                    cardNumber: cardInfo.number.replace(/\s/g, ''),
                    cardExpirationMonth: expiryMonth,
                    cardExpirationYear: `20${expiryYear}`,
                    securityCode: cardInfo.ccv,
                    identificationType: 'CPF',
                    identificationNumber: customerInfo.doc.replace(/\D/g, ''),
                });

                if (!cardToken) return;

                mpPayload.card_token_id = cardToken;
            }
            
            await createMpSubscription(mpPayload);
        }
    };

    const loading = authLoading || plansLoading || mpLoading || gatewayLoading;
    const isSubmitDisabled = loading || !isFormValid || (gatewaySettings?.activeGateway === 'mercado_pago' && !isMercadoPagoReady);

    if (loading && !plan) {
        return <div className="flex justify-center items-center h-screen"><Loader2 className="h-8 w-8 animate-spin" /></div>;
    }

    if (!plan) {
        return <div className="text-center py-20">Plano não encontrado.</div>;
    }

    return (
        <>
            <Helmet>
                <title>Checkout - {plan.name}</title>
            </Helmet>
            <div className="container mx-auto max-w-4xl py-12 px-4">
                <h1 className="text-3xl font-bold mb-2">Finalizar Assinatura</h1>
                <p className="text-muted-foreground mb-8">Você está a um passo de ativar seu plano.</p>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                    <div className="md:col-span-1">
                        <Card>
                            <CardHeader>
                                <CardTitle>Resumo do Pedido</CardTitle>
                            </CardHeader>
                            <CardContent className="space-y-4">
                                <div className="flex justify-between">
                                    <span className="text-muted-foreground">Plano</span>
                                    <span className="font-semibold">{plan.name}</span>
                                </div>
                                <div className="space-y-2">
                                    <Label>Ciclo de Pagamento</Label>
                                    <Select value={billingCycle} onValueChange={setBillingCycle}>
                                        <SelectTrigger>
                                            <SelectValue />
                                        </SelectTrigger>
                                        <SelectContent>
                                            <SelectItem value="monthly">Mensal - {formatCurrency(plan.monthlyPrice)}</SelectItem>
                                            <SelectItem value="annually">Anual - {formatCurrency(plan.annualPrice)}</SelectItem>
                                        </SelectContent>
                                    </Select>
                                </div>
                                <div className="border-t border-border my-4"></div>
                                <div className="flex justify-between text-lg font-bold">
                                    <span>Total</span>
                                    <span>{formatCurrency(getPrice())}</span>
                                </div>
                            </CardContent>
                        </Card>
                    </div>

                    <div className="md:col-span-1">
                        <form onSubmit={handleSubmit} noValidate>
                            <Card>
                                <CardHeader>
                                    <CardTitle>Informações de Pagamento</CardTitle>
                                    <CardDescription>Selecione o método e preencha os dados.</CardDescription>
                                </CardHeader>
                                <CardContent className="space-y-4">
                                    <Select value={paymentMethod} onValueChange={setPaymentMethod}>
                                        <SelectTrigger>
                                            <SelectValue placeholder="Selecione o método de pagamento" />
                                        </SelectTrigger>
                                        <SelectContent>
                                            <SelectItem value="CREDIT_CARD"><CreditCard className="inline-block mr-2 h-4 w-4" />Cartão de Crédito</SelectItem>
                                            <SelectItem value="PIX"><ScanLine className="inline-block mr-2 h-4 w-4" />PIX</SelectItem>
                                        </SelectContent>
                                    </Select>

                                    {paymentMethod === 'CREDIT_CARD' && (
                                        <div className="space-y-4 animate-in fade-in">
                                            <div>
                                                <Label htmlFor="holderName">Nome no Cartão</Label>
                                                <Input id="holderName" name="holderName" value={cardInfo.holderName} onChange={handleCardInputChange} required className={cn({'border-red-500': formErrors.holderName})} />
                                            </div>
                                            <div>
                                                <Label htmlFor="number">Número do Cartão</Label>
                                                <MaskedInput id="number" name="number" mask="9999 9999 9999 9999" value={cardInfo.number} onChange={handleCardInputChange} required className={cn({'border-red-500': formErrors.number})} />
                                            </div>
                                            <div className="grid grid-cols-2 gap-4">
                                                <div>
                                                    <Label htmlFor="expiry">Validade (MM/AA)</Label>
                                                    <MaskedInput id="expiry" name="expiry" mask="99/99" value={cardInfo.expiry} onChange={handleCardInputChange} required className={cn({'border-red-500': formErrors.expiry})} />
                                                </div>
                                                <div>
                                                    <Label htmlFor="ccv">CVV</Label>
                                                    <MaskedInput id="ccv" name="ccv" mask="9999" value={cardInfo.ccv} onChange={handleCardInputChange} required className={cn({'border-red-500': formErrors.ccv})} />
                                                </div>
                                            </div>
                                        </div>
                                    )}

                                    <div className="border-t border-border my-4"></div>

                                    <h3 className="font-semibold">Dados do Pagador</h3>
                                    <div className="space-y-4">
                                        <div><Label htmlFor="fullName">Nome Completo</Label><Input id="fullName" name="fullName" value={customerInfo.fullName} onChange={handleCustomerInfoChange} required className={cn({'border-red-500': formErrors.fullName})} /></div>
                                        <div><Label htmlFor="email">Email</Label><Input id="email" name="email" type="email" value={customerInfo.email} onChange={handleCustomerInfoChange} required className={cn({'border-red-500': formErrors.email})} /></div>
                                        <div><Label htmlFor="phone">Telefone</Label><MaskedInput id="phone" name="phone" mask="(99) 99999-9999" value={customerInfo.phone} onChange={handleCustomerInfoChange} required className={cn({'border-red-500': formErrors.phone})} /></div>
                                        <div><Label htmlFor="doc">CPF</Label><MaskedInput id="doc" name="doc" mask="999.999.999-99" value={customerInfo.doc} onChange={handleCustomerInfoChange} required className={cn({'border-red-500': formErrors.doc})} /></div>
                                        
                                        <div className="grid grid-cols-3 gap-4">
                                            <div className="col-span-1">
                                                <Label htmlFor="zipCode">CEP</Label>
                                                <MaskedInput id="zipCode" name="zipCode" mask="99999-999" value={customerInfo.zipCode} onChange={handleCustomerInfoChange} required className={cn({'border-red-500': formErrors.zipCode})} />
                                            </div>
                                            <div className="col-span-2">
                                                <Label htmlFor="street">Rua</Label>
                                                <Input id="street" name="street" value={customerInfo.street} onChange={handleCustomerInfoChange} required disabled={viaCepLoading} className={cn({'border-red-500': formErrors.street})} />
                                            </div>
                                        </div>
                                        <div className="grid grid-cols-3 gap-4">
                                            <div className="col-span-1">
                                                <Label htmlFor="number">Número</Label>
                                                <Input id="number" name="number" value={customerInfo.number} onChange={handleCustomerInfoChange} required className={cn({'border-red-500': formErrors.number})} />
                                            </div>
                                            <div className="col-span-2">
                                                <Label htmlFor="complement">Complemento</Label>
                                                <Input id="complement" name="complement" value={customerInfo.complement} onChange={handleCustomerInfoChange} />
                                            </div>
                                        </div>
                                        <div>
                                            <Label htmlFor="neighborhood">Bairro</Label>
                                            <Input id="neighborhood" name="neighborhood" value={customerInfo.neighborhood} onChange={handleCustomerInfoChange} required disabled={viaCepLoading} className={cn({'border-red-500': formErrors.neighborhood})} />
                                        </div>
                                        <div className="grid grid-cols-2 gap-4">
                                            <div>
                                                <Label htmlFor="city">Cidade</Label>
                                                <Input id="city" name="city" value={customerInfo.city} onChange={handleCustomerInfoChange} required disabled={viaCepLoading} className={cn({'border-red-500': formErrors.city})} />
                                            </div>
                                            <div>
                                                <Label htmlFor="state">Estado</Label>
                                                <Input id="state" name="state" value={customerInfo.state} onChange={handleCustomerInfoChange} required disabled={viaCepLoading} className={cn({'border-red-500': formErrors.state})} />
                                            </div>
                                        </div>
                                    </div>
                                </CardContent>
                            </Card>
                            <Button type="submit" className="w-full mt-6" disabled={isSubmitDisabled}>
                                {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                                <Lock className="mr-2 h-4 w-4" />
                                Pagar com Segurança
                            </Button>
                        </form>
                    </div>
                </div>
            </div>
        </>
    );
};

export default CheckoutPage;