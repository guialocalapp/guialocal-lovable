import React, { useState, useMemo, useRef, useEffect } from 'react';
import { Helmet } from 'react-helmet-async';
import { motion } from 'framer-motion';
import { Link, useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { Search, MapPin, Tag, Loader2 } from 'lucide-react';
import { useCities } from '@/hooks/useCities';
import { useAds } from '@/hooks/useAds.jsx';
import { useCategories } from '@/hooks/useCategories';
import AdCard from '@/components/site/AdCard';
import HomeBanner from '@/components/site/HomeBanner';

const CategoryOptions = ({ categories, level = 0 }) => {
    return categories.map(cat => (
      <React.Fragment key={cat.id}>
        <SelectItem value={cat.slug} style={{ paddingLeft: `${level * 1.5}rem` }}>
           {cat.name}
        </SelectItem>
        {cat.children && cat.children.length > 0 && (
          <CategoryOptions categories={cat.children} level={level + 1} />
        )}
      </React.Fragment>
    ));
};

const Home = () => {
  const { cities } = useCities();
  const { structuredCategories } = useCategories();
  const { publicAds, loading: adsLoading, fetchPublicAds } = useAds();
  
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCitySlug, setSelectedCitySlug] = useState('todos');
  const [selectedCategorySlug, setSelectedCategorySlug] = useState('all');
  
  const navigate = useNavigate();

  useEffect(() => {
    fetchPublicAds({ page: 1, limit: 6 });
  }, [fetchPublicAds]);

  const handleSearch = (e) => {
    e.preventDefault();
    const cityPath = selectedCitySlug === 'todos' ? 'todos' : selectedCitySlug;
    let path = `/anuncios/cidade/${cityPath}`;
    
    const searchParams = new URLSearchParams();

    if (searchTerm.trim()) {
        searchParams.set('q', searchTerm.trim());
    } 
    
    if (selectedCategorySlug && selectedCategorySlug !== 'all') {
        path += `/${selectedCategorySlug}`;
    }

    const queryString = searchParams.toString();
    navigate(`${path}${queryString ? `?${queryString}` : ''}`);
  };

  const recentAds = useMemo(() => {
    if (!publicAds) return [];
    return publicAds
      .sort((a, b) => new Date(b.created_at) - new Date(a.created_at))
      .slice(0, 6);
  }, [publicAds]);


  return <>
                <Helmet>
                    <title>Guia Local - Encontre os melhores serviços e empresas da sua cidade</title>
                    <meta name="description" content="O Guia Local é a sua ponte para os melhores restaurantes, lojas e serviços em Gravataí e Cachoeirinha. Anuncie seu negócio ou encontre o que precisa!" />
                    <meta property="og:title" content="Guia Local - Conectando você ao coração da cidade" />
                    <meta property="og:description" content="Encontre os melhores comércios, restaurantes e serviços em sua cidade." />
                </Helmet>
    
                <HomeBanner />
    
                <div id="search" className="-mt-16 relative z-20">
                    <div className="container mx-auto px-4">
                        <motion.div 
                          className="bg-card/80 backdrop-blur-md p-6 rounded-lg shadow-2xl border border-border" 
                          initial={{ opacity: 0, y: 50 }} 
                          animate={{ opacity: 1, y: 0 }} 
                          transition={{ duration: 0.8, delay: 0.6 }}
                        >
                            <form onSubmit={handleSearch} className="flex flex-wrap items-end gap-4">
                                <div className="flex-1 min-w-[180px] space-y-2">
                                    <Label htmlFor="search-term" className="flex items-center text-muted-foreground"><Search className="w-4 h-4 mr-2" /> Busca</Label>
                                    <Input
                                        id="search-term"
                                        placeholder="O que você procura?"
                                        value={searchTerm}
                                        onChange={(e) => setSearchTerm(e.target.value)}
                                    />
                                </div>
                                <div className="flex-1 min-w-[180px] space-y-2">
                                    <Label htmlFor="category-search" className="flex items-center text-muted-foreground"><Tag className="w-4 h-4 mr-2" /> Categoria</Label>
                                    <Select value={selectedCategorySlug} onValueChange={setSelectedCategorySlug}>
                                        <SelectTrigger id="category-search">
                                            <SelectValue placeholder="Selecione..." />
                                        </SelectTrigger>
                                        <SelectContent>
                                            <SelectItem value="all">Todas as Categorias</SelectItem>
                                            <CategoryOptions categories={structuredCategories} />
                                        </SelectContent>
                                    </Select>
                                </div>
                                <div className="flex-1 min-w-[180px] space-y-2">
                                    <Label htmlFor="city-search" className="flex items-center text-muted-foreground"><MapPin className="w-4 h-4 mr-2" /> Cidade</Label>
                                    <Select value={selectedCitySlug} onValueChange={setSelectedCitySlug}>
                                        <SelectTrigger id="city-search">
                                            <SelectValue placeholder="Selecione..." />
                                        </SelectTrigger>
                                        <SelectContent>
                                            <SelectItem value="todos">Todas as cidades</SelectItem>
                                            {cities.map(city => <SelectItem key={city.slug} value={city.slug}>{city.name}/{city.state}</SelectItem>)}
                                        </SelectContent>
                                    </Select>
                                </div>
                                <Button type="submit" className="w-full sm:w-auto flex-shrink-0">Buscar</Button>
                            </form>
                        </motion.div>
                    </div>
                </div>
    
                <div className="py-24 sm:py-32 bg-background">
                    <div className="mx-auto max-w-7xl px-6 lg:px-8">
                        <div className="mb-10 text-center">
                            <p className="text-xl md:text-2xl font-bold text-foreground">
                                No momento, a plataforma Guia Local atende exclusivamente as cidades de <span className="text-primary">Gravataí/RS</span> e <span className="text-primary">Cachoeirinha/RS</span>.
                            </p>
                        </div>
                        <h2 className="text-center text-3xl font-bold tracking-tight text-foreground sm:text-4xl">Novidades</h2>
                        
                        {adsLoading ? (
                            <div className="flex justify-center items-center mt-10">
                                <Loader2 className="h-12 w-12 animate-spin text-primary" />
                            </div>
                        ) : recentAds.length > 0 ? (
                            <div className="mt-10 grid grid-cols-1 gap-x-6 gap-y-10 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 xl:gap-x-8">
                                {recentAds.map((ad) => (
                                    <AdCard key={ad.id} ad={ad} />
                                ))}
                            </div>
                        ) : (
                            <div className="mt-10 text-center text-muted-foreground">
                                <p>Nenhum anúncio em destaque encontrado no momento.</p>
                            </div>
                        )}

                        <div className="mt-16 text-center">
                            <Button asChild size="lg" className="bg-primary hover:bg-primary/90 text-primary-foreground shadow-lg shadow-primary/20">
                                <Link to="/anuncios">Ver todos os anúncios</Link>
                            </Button>
                        </div>
                    </div>
                </div>
            </>;
};
export default Home;