import React from 'react';
import { Helmet } from 'react-helmet-async';

const AboutPage = () => {
  return (
    <>
      <Helmet>
        <title>Quem Somos - Guia Local</title>
        <meta name="description" content="Saiba mais sobre a nossa missão de conectar a comunidade local com os melhores serviços e comércios da cidade." />
      </Helmet>
      <div className="container mx-auto px-4 py-12 md:px-6 lg:py-16">
        <div className="max-w-3xl mx-auto">
          <h1 className="text-3xl font-bold tracking-tight text-gray-900 dark:text-gray-100 sm:text-4xl">
            Quem Somos
          </h1>
          <div className="mt-8 prose prose-lg text-gray-600 dark:text-gray-300">
            <p>
              Bem-vindo ao Guia Local, sua principal fonte para descobrir e se conectar com os melhores estabelecimentos e serviços em sua cidade. Nossa missão é simples: fortalecer a economia local, tornando mais fácil para os moradores encontrarem exatamente o que precisam, ao mesmo tempo em que oferecemos aos empresários uma plataforma poderosa para alcançar seu público.
            </p>
            <p>
              Nascemos da paixão pela nossa comunidade e da crença de que o comércio local é o coração de qualquer cidade vibrante. Em um mundo cada vez mais digital, queríamos criar um espaço que celebrasse e apoiasse os empreendedores que dão vida às nossas ruas.
            </p>
            <p>
              Aqui, você encontrará desde o seu novo restaurante favorito até um profissional de confiança para aquele conserto em casa. Cada anúncio é uma porta de entrada para uma nova experiência, e estamos orgulhosos de ser a ponte que conecta você a elas.
            </p>
            <p>
              Junte-se a nós nesta jornada para celebrar e apoiar o que nossa cidade tem de melhor. Explore, descubra e conecte-se!
            </p>
          </div>
        </div>
      </div>
    </>
  );
};

export default AboutPage;