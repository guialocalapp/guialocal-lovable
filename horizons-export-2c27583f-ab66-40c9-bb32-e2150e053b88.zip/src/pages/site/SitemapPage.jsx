import React, { useState, useEffect } from 'react';
import { useLoading } from '@/contexts/LoadingContext';

const SitemapPage = () => {
  const [xmlContent, setXmlContent] = useState('');
  const { showLoader, hideLoader } = useLoading();

  useEffect(() => {
    const fetchSitemap = async () => {
      showLoader();
      try {
        const sitemapUrl = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/listings-sitemap`;
        const response = await fetch(sitemapUrl);
        if (!response.ok) {
          throw new Error(`HTTP error! status: ${response.status}`);
        }
        const text = await response.text();
        setXmlContent(text);

        // Set the content type of the document
        document.documentElement.setAttribute('xmlns', 'http://www.sitemaps.org/schemas/sitemap/0.9');
        document.title = 'Sitemap de Anúncios';
      } catch (error) {
        console.error("Failed to fetch sitemap:", error);
        setXmlContent('<!-- Error fetching sitemap -->');
      } finally {
        hideLoader();
      }
    };

    fetchSitemap();

    // Cleanup function to remove the attribute when the component unmounts
    return () => {
      document.documentElement.removeAttribute('xmlns');
    };
  }, [showLoader, hideLoader]);

  useEffect(() => {
    if (xmlContent) {
      // Directly write the XML content to the document
      // This replaces the entire React app content with the raw XML string
      document.open('text/xml', 'replace');
      document.write(xmlContent);
      document.close();
    }
  }, [xmlContent]);

  // This component will be replaced by the document.write, so it just needs to return null.
  return null;
};

export default SitemapPage;