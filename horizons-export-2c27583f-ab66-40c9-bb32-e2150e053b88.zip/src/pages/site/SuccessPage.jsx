import React, { useEffect } from 'react';
    import { Link, useNavigate } from 'react-router-dom';
    import { Helmet } from 'react-helmet-async';
    import { Button } from '@/components/ui/button';
    import { CheckCircle } from 'lucide-react';
    import { useAuth } from '@/hooks/useAuth';

    const SuccessPage = () => {
        const navigate = useNavigate();
        const { refreshUserProfile } = useAuth();

        useEffect(() => {
            const updateUserAndRedirect = async () => {
                await refreshUserProfile();

                const timer = setTimeout(() => {
                    navigate('/client/dashboard');
                }, 5000);

                return () => clearTimeout(timer);
            };
            
            updateUserAndRedirect();

        }, [navigate, refreshUserProfile]);

        return (
            <>
                <Helmet>
                    <title>Pagamento Realizado com Sucesso - Guia Local</title>
                </Helmet>
                <div className="min-h-screen flex flex-col items-center justify-center bg-background text-foreground">
                    <div className="text-center p-8 max-w-lg w-full">
                        <CheckCircle className="mx-auto h-20 w-20 text-green-500" />
                        <h1 className="mt-6 text-4xl font-extrabold tracking-tight">Pagamento bem-sucedido!</h1>
                        <p className="mt-4 text-lg text-muted-foreground">
                            Obrigado pela sua assinatura! Seu plano foi ativado com sucesso. Você será redirecionado para o seu painel em breve.
                        </p>
                        <div className="mt-8">
                            <Button asChild>
                                <Link to="/client/dashboard">Ir para o Painel</Link>
                            </Button>
                        </div>
                    </div>
                </div>
            </>
        );
    };

    export default SuccessPage;