import React from 'react';
import { Helmet } from 'react-helmet-async';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { DollarSign, UserPlus, Link as LinkIcon, CheckCircle, Rocket, Target, Gift } from 'lucide-react';
import { motion } from 'framer-motion';

const FeatureCard = ({ icon, title, description }) => (
  <div className="flex flex-col items-center text-center p-6 bg-card rounded-lg shadow-md border border-border">
    <div className="mb-4 text-primary bg-primary/10 p-3 rounded-full">
      {icon}
    </div>
    <h3 className="text-xl font-bold mb-2 text-foreground">{title}</h3>
    <p className="text-muted-foreground">{description}</p>
  </div>
);

const StepCard = ({ icon, title, description }) => (
    <div className="flex items-start space-x-4">
        <div className="flex-shrink-0 mt-1 text-primary bg-primary/10 p-3 rounded-full">
            {icon}
        </div>
        <div>
            <h3 className="text-lg font-semibold text-foreground">{title}</h3>
            <p className="text-muted-foreground">{description}</p>
        </div>
    </div>
);

const AffiliatesPage = () => {
  return (
    <>
      <Helmet>
        <title>Programa de Afiliados - Guia Local</title>
        <meta name="description" content="Junte-se ao nosso programa de afiliados e ganhe dinheiro indicando novos clientes para o Guia Local. É fácil, rápido e lucrativo!" />
      </Helmet>

      <div className="bg-background text-foreground">
        {/* Hero Section */}
        <section className="relative py-20 md:py-32 bg-secondary">
            <div className="absolute inset-0 bg-gradient-to-br from-background to-secondary/50 opacity-50"></div>
            <div className="container mx-auto px-4 text-center relative z-10">
                <motion.h1 
                    className="text-4xl md:text-6xl font-extrabold text-primary mb-4"
                    initial={{ opacity: 0, y: -20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.5 }}
                >
                    Seja um Afiliado Guia Local
                </motion.h1>
                <motion.p 
                    className="text-lg md:text-xl text-muted-foreground max-w-3xl mx-auto mb-8"
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.5, delay: 0.2 }}
                >
                    Ganhe dinheiro ajudando empresas locais a crescer. Indique novos clientes para nossa plataforma e seja recompensado por isso!
                </motion.p>
                <motion.div
                    initial={{ opacity: 0, scale: 0.8 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ duration: 0.5, delay: 0.4 }}
                >
                    <Button asChild size="lg" className="bg-primary hover:bg-primary/90 text-primary-foreground shadow-lg">
                        <Link to="/cadastro">Quero ser um Afiliado Agora!</Link>
                    </Button>
                </motion.div>
            </div>
        </section>

        {/* Why become an affiliate? */}
        <section className="py-16 md:py-24">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl md:text-4xl font-bold text-center mb-12 text-foreground">Por que ser um Afiliado?</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <FeatureCard
                icon={<DollarSign size={32} />}
                title="Renda Extra"
                description="Ganhe comissões por cada novo cliente que assinar um plano através do seu link de afiliado."
              />
              <FeatureCard
                icon={<Rocket size={32} />}
                title="Fácil de Começar"
                description="O cadastro é simples e rápido. Em poucos minutos, você já pode começar a divulgar seu link."
              />
              <FeatureCard
                icon={<Target size={32} />}
                title="Ajude o Comércio Local"
                description="Faça parte do movimento que fortalece os negócios da sua cidade, conectando-os a mais clientes."
              />
            </div>
          </div>
        </section>

        {/* How it works */}
        <section className="py-16 md:py-24 bg-secondary">
            <div className="container mx-auto px-4">
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
                    <div>
                        <h2 className="text-3xl md:text-4xl font-bold mb-8 text-foreground">Como Funciona? É simples!</h2>
                        <div className="space-y-8">
                            <StepCard 
                                icon={<UserPlus size={24} />}
                                title="1. Cadastre-se na Plataforma"
                                description="Crie sua conta gratuitamente no Guia Local. O processo é rápido e leva menos de 2 minutos."
                            />
                            <StepCard 
                                icon={<LinkIcon size={24} />}
                                title="2. Acesse seu Link de Afiliado"
                                description="Após o cadastro, acesse seu painel de cliente, vá para a seção 'Afiliados' e copie seu link exclusivo."
                            />
                            <StepCard 
                                icon={<Gift size={24} />}
                                title="3. Divulgue e Ganhe"
                                description="Compartilhe seu link com comerciantes e empresários. A cada novo cliente que assinar um plano, você ganha!"
                            />
                        </div>
                    </div>
                    <div className="aspect-w-16 aspect-h-9 rounded-lg overflow-hidden shadow-2xl">
                        <iframe
                            src="https://www.youtube.com/embed/dQw4w9WgXcQ"
                            frameBorder="0"
                            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                            allowFullScreen
                            className="w-full h-full"
                            title="Vídeo Explicativo do Programa de Afiliados"
                        ></iframe>
                    </div>
                </div>
            </div>
        </section>

        {/* Final CTA */}
        <section className="py-20 md:py-28">
          <div className="container mx-auto px-4 text-center">
            <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">Pronto para Começar a Lucrar?</h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto mb-8">
              Não perca tempo! Junte-se a nós e comece a transformar suas conexões em uma fonte de renda.
            </p>
            <Button asChild size="lg" className="bg-primary hover:bg-primary/90 text-primary-foreground shadow-lg animate-pulse">
              <Link to="/cadastro">Cadastre-se e Vire um Afiliado!</Link>
            </Button>
          </div>
        </section>
      </div>
    </>
  );
};

export default AffiliatesPage;