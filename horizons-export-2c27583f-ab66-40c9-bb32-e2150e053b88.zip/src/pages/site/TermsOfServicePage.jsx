import React from 'react';
import { Helmet } from 'react-helmet-async';

const TermsOfServicePage = () => {
  return (
    <>
      <Helmet>
        <title>Termos de Serviço - Guia Local</title>
        <meta name="description" content="Leia os nossos Termos de Serviço para entender as regras e diretrizes para usar a plataforma Guia Local." />
      </Helmet>
      <div className="container mx-auto px-4 py-12 md:px-6 lg:py-16">
        <div className="max-w-3xl mx-auto">
          <h1 className="text-3xl font-bold tracking-tight text-gray-900 dark:text-gray-100 sm:text-4xl">
            Termos de Serviço
          </h1>
          <div className="mt-8 prose prose-lg text-gray-600 dark:text-gray-300">
            <p><strong>Última atualização:</strong> 09 de Setembro de 2025</p>

            <h2>1. Termos</h2>
            <p>
              Ao acessar ao site Guia Local, concorda em cumprir estes termos de serviço, todas as leis e regulamentos aplicáveis e concorda que é responsável pelo cumprimento de todas as leis locais aplicáveis. Se você não concordar com algum desses termos, está proibido de usar ou acessar este site. Os materiais contidos neste site são protegidos pelas leis de direitos autorais e marcas comerciais aplicáveis.
            </p>

            <h2>2. Uso de Licença</h2>
            <p>
              É concedida permissão para baixar temporariamente uma cópia dos materiais (informações ou software) no site Guia Local, apenas para visualização transitória pessoal e não comercial. Esta é a concessão de uma licença, não uma transferência de título e, sob esta licença, você não pode:
            </p>
            <ul>
              <li>modificar ou copiar os materiais;</li>
              <li>usar os materiais para qualquer finalidade comercial ou para exibição pública (comercial ou não comercial);</li>
              <li>tentar descompilar ou fazer engenharia reversa de qualquer software contido no site Guia Local;</li>
              <li>remover quaisquer direitos autorais ou outras notações de propriedade dos materiais; ou</li>
              <li>transferir os materiais para outra pessoa ou 'espelhe' os materiais em qualquer outro servidor.</li>
            </ul>
            <p>
              Esta licença será automaticamente rescindida se você violar alguma dessas restrições e poderá ser rescindida pelo Guia Local a qualquer momento.
            </p>

            <h2>3. Isenção de responsabilidade</h2>
            <p>
              Os materiais no site da Guia Local são fornecidos 'como estão'. O Guia Local não oferece garantias, expressas ou implícitas, e, por este meio, isenta e nega todas as outras garantias, incluindo, sem limitação, garantias implícitas ou condições de comercialização, adequação a um fim específico ou não violação de propriedade intelectual ou outra violação de direitos.
            </p>

            <h2>4. Limitações</h2>
            <p>
              Em nenhum caso o Guia Local ou seus fornecedores serão responsáveis por quaisquer danos (incluindo, sem limitação, danos por perda de dados ou lucro ou devido a interrupção dos negócios) decorrentes do uso ou da incapacidade de usar os materiais em Guia Local, mesmo que o Guia Local ou um representante autorizado da Guia Local tenha sido notificado oralmente ou por escrito da possibilidade de tais danos.
            </p>

            <h2>5. Modificações</h2>
            <p>
              O Guia Local pode revisar estes termos de serviço do site a qualquer momento, sem aviso prévio. Ao usar este site, você concorda em ficar vinculado à versão atual desses termos de serviço.
            </p>

            <h2>6. Lei aplicável</h2>
            <p>
              Estes termos e condições são regidos e interpretados de acordo com as leis do Guia Local e você se submete irrevogavelmente à jurisdição exclusiva dos tribunais naquele estado ou localidade.
            </p>
          </div>
        </div>
      </div>
    </>
  );
};

export default TermsOfServicePage;